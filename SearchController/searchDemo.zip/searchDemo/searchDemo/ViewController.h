//
//  ViewController.h
//  searchDemo
//
//  Created by 帝炎魔 on 16/3/25.
//  Copyright © 2016年 帝炎魔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

