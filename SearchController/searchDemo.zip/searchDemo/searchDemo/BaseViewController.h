//
//  BaseViewController.h
//  searchDemo
//
//  Created by 帝炎魔 on 16/3/25.
//  Copyright © 2016年 帝炎魔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UITableViewController <UISearchResultsUpdating, UISearchControllerDelegate>


// 空的搜索字符串展示所有的数据
// 如果有字符串 再用过滤器展示有关信息

@property (nonatomic, copy) NSString *filterString;


@property (copy) NSArray *allResults;

// 搜索结果集
@property (readwrite, copy) NSArray *visibleResults;

// 创建搜索框
@property (nonatomic, strong) UISearchController *searchController;


@end
